import React,{useState,useEffect} from 'react'
import axios from "axios";
import {Link} from 'react-router-dom'

const BillTable=()=>
{
    //useState with blank array
    const [Billing,setBills]= useState([]);

    //to perform some action on a page
    //we will call loadBills on page load 
    useEffect(()=>
    {
       loadBills();

    },[]);
    const loadBills= async ()=>
    {
        //await will wait untill the request is not completed
        const result=await axios.get("http://localhost:9177/viewall");
        //Axios is a HttpClient --> get,put,delete,post all return Promise
       //set the data to Home page
       console.log(result.data)
       setBills(result.data);
    }


 //delete user method
 const deleteBills = async (id) =>
 {
     await axios.delete(`http://localhost:9177/delete/${id}`);
     //call load Bills
     loadBills();
 }



    console.log('render ',Billing)
    return(

        <div className="container">
        <div className="py-4">
            <h1>Home Page</h1>
<table className="table border shadow">
<thead class="thead-dark">
<tr>
  <th scope="col">customerId</th>
  <th scope="col">BillNum</th>
  <th scope="col">grandTotal</th>
  <th scope="col">Units</th>
  <th scope="col">Date</th>
  <th>Action</th>
</tr>
</thead>
<tbody>
{
Billing.map((bill,index)=>(
  
<tr>
<th scope="row">{index+1}</th>
<td>{bill.customerId}</td>
<td>{bill.BillNum}</td>
<td>{bill.grandTotal}</td>
<td>{bill.Units}</td>
<td>{bill.Date}</td>
</tr>
)
) // map closed
}
</tbody>
</table>
</div>
</div>
 )


}
  
export default BillTable;