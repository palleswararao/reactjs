
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
// import { useHistory } from "react-router-dom";
import {
  billingDoneAction
} from "../redux/BillingReducer";

export function BillingUpsert() {
  const dispatch = useDispatch();
  // const history = useHistory();

  const state = useSelector((state) => state);
  console.log(state);

  
  const [billNum, setBillNum] = useState(state.bill.refemp.billNum);
  

  //Adding Bill Details
  const [customerId, setCustomerId] = useState(state.bill.refemp.customerId);
  const [units, setUnits] = useState(state.bill.refemp.units);
  const [grandTotal, setGrandTotal] = useState(state.bill.refemp.grandTotal);
  const [date, setDate] = useState(state.bill.refemp.date);

  const [successOperation, setSuccessOperation] = useState(false);
  //const [errorOperation, setErrorOperation] = useState(false);

  
  const updateCustomerId = (e) => setCustomerId(e.target.value);
  
  const updateBillNum= (e) => setBillNum(e.target.value);
  const updateUnits = (e) => setUnits(e.target.value);
  const updateGrandTotal = (e) => setGrandTotal(e.target.value);
  const updateDate = (e) => setDate(e.target.value);
 


  const BillingDone = (e) => {
    e.preventDefault();
    console.log( customerId, billNum, units, grandTotal, date);

    // Validations
   

    const re1 = /^[0-9]+$/;
    if (!re1.test(grandTotal)) {
      alert("Invalid amount");
      return;
    }

    const re2 = /^[0-9]{3}$/;
    if (!re2.test(billNum)) {
      alert("Invalid bill Number");
      return;
    }

    const re3 = /^[0-9]{3}$/;
    if (!re3.test(units)) {
      alert("Invalid units");
      return;
    }
    
    const re4 = /^[1-9][0-9]{2}$/;
    if (!re4.test(customerId)) {
      alert("Invalid customerid");
      return;
    }

    // THIS IS REDUX ACTION CALLING
    dispatch(
      billingDoneAction({
        
        customerId,
        billNum,
        units,
        grandTotal,
        date,
      })
    );

    // A1 success
    setSuccessOperation(true);
    setTimeout(() => setSuccessOperation(false), 5000);

    // history.push("/list-employee");

   
    setGrandTotal("");
    setCustomerId("");
    setBillNum("");
    setUnits("");
    setDate("");
  };

  // const updateBill = () => {
  //   dispatch(
  //     updateBillingAction({
  //       id: state.bill.refemp.id,
  //       billId,
  //       billNum,
  //       CustomerId,
  //       units,
  //       grandTotal,
  //       Date,
  //     })
  //   );

  // 
  //   setBillNum("");
  //   setCustomerId("");
  //   setUnits("");
  //   setgrandTotal("");
  //   setDate("");
  // };

  return (
    <div style={{ height: "100vh", backgroundColor: "#DFDF00" }}>
      <div className="row">
        <div className="col-3 col-md-3 d-none d-md-block"></div>
        <div className="col-12 col-md-6">
          <h3 className="text-center alert alert-primary">
            Bill Details
          </h3>

          {successOperation && (
            <div className="alert alert-success">Bill Details added Successfully</div>
          )}

          {/* <form ref={formEL} class="needs-validation" novalidate> */}
          
          <div className="mb-1">
            <input
              type="number"
              value={billNum}
              onChange={(e) => updateBillNum(e)}
              className="form-control mb-2"
              placeholder="Enter Bill Number"
              required
            />
          </div>
          <div className="mb-1">
            <input
              type="number"
              value={units}
              onChange={(e) => updateUnits(e)}
              className="form-control mb-2"
              placeholder="Enter Units"
              required
              

              
            />
          </div>

          <div className="mb-1">
            <input
              type="date"
              value={date}
              onChange={(e) => updateDate(e)}
              className="form-control mb-2"
              placeholder="Enter Date"
              maxLength="16"
              minLength="16"
              required

            />
          </div>

          <div className="mb-1">
            <input
              type="number"
              value={grandTotal}
              onChange={(e) => updateGrandTotal(e)}
              className="form-control mb-2"
              placeholder="Enter GrandTotal"
              maxLength="5"
              minLength="3"
              required

            />
          </div>

         
          <div className="mb-1">
            <input
              type="number"
              value={customerId}
              onChange={(e) => updateCustomerId(e)}
              className="form-control mb-2"
              placeholder="Enter Customer Id"
              required

            />
          </div>
          <div className="mb-1">
            {/* {state.bill.refemp.id ? (
              <input
                type="button"
                className="btn btn-primary w-100"
                value="Update Bill"
                onClick={() => updateBill()}
              />
            ) : ( */}
              <input
                type="button"
                className="btn btn-primary w-100"
                value="ADDBILL"
                onClick={(e) => BillingDone(e)}
              />
            {/* )} */}
          </div>
          {/* </form> */}
        </div>
        <div className="col-3 col-md-3  d-none d-md-block"></div>
      </div>
    </div>
  );
}
