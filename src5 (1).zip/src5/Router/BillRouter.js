import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import TopMenu from '../components/TopMenu';
import Home from '../Pages/Home';
import BillingForm from '../components/BillingForm';
import BillTable from '../components/BillTable';
import AppNavBar from '../common/AppNavBar';
import AddBill from '../service/AddBill';
import EditBill from '../service/EditBill';
//import NotFound from '../components/NotFound';

const BillRouter = () => (
    <BrowserRouter>
        <div className='container'>
            <Home />
            <AppNavBar/>
            <Switch>
            <Route path="/billingform" ><BillingForm /></Route>
            <Route path="/billtable" ><BillTable/></Route>
                         <Route path="/add" component={AddBill} />
                <Route path="/bill/:id" component={EditBill} />

            </Switch>
        </div>
    </BrowserRouter>
);

export default BillRouter;