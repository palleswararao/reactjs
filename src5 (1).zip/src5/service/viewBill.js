import React, { Component } from 'react'
import {connect} from 'react-redux'
import {getbills} from '../../actions/bill'
//import {getUsers} from '../../actions/bills'

import axios from 'axios';
 class viewBill extends Component {
     
     constructor(props)
    
     {
         super(props);
         this.props.getBills();
         this.state=
         {
             bills:{}
         }
         
     }
        
       
     componentDidMount()
     {
        this.setState({complaints:this.props.bills});
     }
   
     

       
    render() {
        const res = this.props.bills;
       // console.log(this.props.bills);
       // console.log(res);
        console.log(this.state.bills);
       // console.log(this.state.bills);
     //   const res=this.props.bills;
    
       
        return (
            <div>
                <h3>Data</h3>
            
                
             { res.map(data => {
                return (
                    <ol key={data.billId}>
                     <li> {data.billNum}</li>  
                     <li> {data.units}</li>
                     <li> {data.grandTotal}</li>
                     <li> {data.Date}</li>
                    </ol>
                );
            })}  
        
                <button onClick={this.handle}>Click Me</button>
                <h1>hello world</h1>
            </div>
        )
    }
}

const mapStateToProps  = (state) => ({bills:state.Bill})

export default connect(mapStateToProps, {getBills})(viewBill)