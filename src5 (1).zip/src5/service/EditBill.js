import React from 'react';

import { connect } from 'react-redux';
import Bills from '../actions/Bills';
import BillingForm from '../components/BillingForm';
const EditBill = (props) => (
    <div>
        <h3>Set Bill information:</h3>
        <BillingForm
            onSubmitBill={(bill) => {
                props.dispatch(EditBill(bill));
                props.history.push('/billingform');
            }}
        />
    </div>
);

export default connect()(EditBill);