import React from 'react';
import BillingForm from '../components/BillingForm';
import { connect } from 'react-redux';
//import { AddBill } from '../actions/Bills';

const AddBill = (props) => (
    <div>
        <h3>Set Bill information:</h3>
        <BillingForm
            onSubmitBill={(bill) => {
                props.dispatch(AddBill(bill));
                //props.history.push('/billingform');
            }}
        />
    </div>
);

export default connect()(AddBill);
