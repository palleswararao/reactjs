import logo from "./logo.svg";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import "./App.css";
import BillingForm from "./components/BillingForm";
import BillTable from "./components/BillTable";
import { Nav, Navbar } from "react-bootstrap";
import AppNavBar from "./common/AppNavBar";

function App() {
  return (
    <Router>
      <AppNavBar />

      <Switch>
        <Route path="/BillingForm">
          <BillingForm />
        </Route>

        <Route path="/BillTable">
          <BillTable />
        </Route>

        <Route exact path="/">
          <BillingForm/>
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
