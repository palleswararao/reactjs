import { createStore, applyMiddleware } from "redux";
import billing from '../reducers/billing';
import thunk from 'redux-thunk';

export default () => {
    return createStore(billing, applyMiddleware(thunk));
};