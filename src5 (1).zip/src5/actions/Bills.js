import axios from '../axios/axios';

const _AddBill = (bill) => ({
    type: 'ADD_BILL',
    bill
});

export const AddBill = (BillData = {
    CustomerId: '',
    billId: '',
    billNum:'',
    grandTotal: '',
    date:'',
    units: 0

}) => {
    return (dispatch) => {
        const Bill = {
            CustomerId: BillData.CistomerId,
            billId: BillData.billId,
            billNum: BillData.billNum,
            grandTotal: BillData.grandTotal,
            date:BillData.date,
            units:BillData.units,
        };

        return axios.post('addbills', Bill).then(result => {
            dispatch(_AddBill(result.bill));
        });
    };
};

const _removeBill = ({ id } = {}) => ({
    type: 'REMOVE_BILL',
    id
});

export const removeBill = ({ id } = {}) => {
    return (dispatch) => {
        return axios.delete(`delete/${id}`).then(() => {
            dispatch(_removeBill({ id }));
        })
    }
};

const _editBill = (id, updates) => ({
    type: 'EDIT_BILL',
    id,
    updates
});

export const editBill = (id, updates) => {
    return (dispatch) => {
        return axios.put(`update`, updates).then(() => {
            dispatch(_editBill(id, updates));
        });
    }
};

const _getBills = (bills) => ({
    type: 'GET_BILLs',
    bills
});

export const getBills = () => {
    return (dispatch) => {
        return axios.get('viewall').then(result => {
            const bills = [];

            result.data.forEach(item => {
                bills.push(item);
            });

            dispatch(_getBills(result.bills));
        });
    };
};