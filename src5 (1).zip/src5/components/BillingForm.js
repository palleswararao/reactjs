import React from 'react';

import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import { Formik, Field, Form, ErrorMessage } from 'formik'
import { FormHelperText } from '@material-ui/core'
import * as Yup from 'yup';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';



export default class BillingForm extends React.Component {
    constructor(props) {
        super(props);
        this.handleCid = this.handleCid.bind(this);
        this.handleBid = this.handleBid.bind(this);
        this.handleBNum = this.handleBNum.bind(this);
        this.handleGrandTotal = this.handleGrandTotal.bind(this);
        this.handleDate = this.handleDate.bind(this);
        this.handleUnits = this.handelUnits.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

        this.state = {
            CustomerId: '',
            billId: '',
            billNum:  '',
            grandTotal: '',
            units:   '',
            error: ''
        };
    }
    


    handleCid(e) {
       
        this.setState(() => ({ CustomerId: e.target.value }));
       console.log(this.state.CustomerId);
    }

   handleBid(e) {
        
        this.setState(() => ({ billId:  e.target.value}));
        console.log(this.state.billId);
    }

    handleBNum(e) {
       
        this.setState(() => ({ billNum:e.target.value }));
        console.log(this.state.billNum);
    }

    handleDate(e) {
        
        this.setState(() => ({ date: e.target.value}));
        console.log(this.state.date);
    }
    handleUnits(e) {
      
      this.setState(() => ({ units:e.target.value}));
      console.log(this.state.units);
  }
  handleGrandTotal(e) {
    
    this.setState(() => ({ grandTotal:e.target.value}));
     console.log(this.state.grandTotal);
}
    handleSubmit(e) {
console.log("hello");
        e.preventDefault();
        console.log("Hi");
        if (!this.state.billId || !this.state.CustomerId || !this.state.grandTotal || !this.state.billNum || this.state.date||this.state.units) {
            this.setState(() => ({ error: 'Please set CustomerId & grandTotal!' }));
        } else {
            this.setState(() => ({ error: '' }));
            this.props.onSubmitBill(
                {
                  CustomerId: this.state.CustomerId,
                    billId: this.state.billId,
                    billNum:this.state.billNum,
                    grandTotal: this.state.grandTotal,
                    date: this.state.date,
                    units:this.state.units
                    
                }
            );
        }
    }
    
   render() 
   {
  return (

    <Container component="main" maxWidth="xs">
      {this.state.error && <p className='error'>{this.state.error}</p>}
               
      <CssBaseline />
     
      
        
        <Typography component="h1" variant="h5" align="center">
          Customer Readings
        </Typography>
        
        <form onSubmit={this.handleSubmit} className='add-bill-form'>
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="cid"
            label="CustomerId"
            name="cid"
            type="number"
            autoComplete="cid"
            autoFocus
            value={this.state.CustomerId}
            onChange={this.handleCid}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="bid"
            label="BillId"
            name="bid"
            type="number"
            autoComplete="bid"
            autoFocus
            value={this.state.billId}
            onChange={this.handleBid}
          />
            <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="bnum"
            label="BillNum"
            name="bnum"
            type="number"
            autoComplete="bnum"
            autoFocus
            value={this.state.billNum}
            onChange={this.handleBNum}
          />
            <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="amt"
            label="Units"
            name="amt"
            type="number"
            autoComplete="amt"
            autoFocus
            value={this.state.units}
            onChange={this.handleUnits}
          />
            <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="bid"
            label="grandTotal"
            name="bid"
            type="number"
            autoComplete="bid"
            autoFocus
            value={this.state.grandTotal}
            onChange={this.handleGrandTotal}
          />
            <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="bid"
            label="Date"
            name="bid"
            type="date"
            autoComplete="bid"
            value={this.state.Date}
            onChange={this.handleDate} 
          />
        
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="secondary"
          >
            Add bill
          </Button>
          
        </form>
       <Box mt={8}>   
       </Box>
    </Container>
  );
}
}