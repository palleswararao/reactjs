import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';


const Billing = ({ CustomerId, billId, billNum, grandTotal, date, units }) => (
    <div>
        
        <p>CustomerId: {CustomerId}</p>
        <p>billId: {billId}</p>
        <p>billNum: {billNum}</p>
        <p>grandTotal: {grandTotal}</p>
        <p>date: {date}</p>
        <p>units: {units}</p>
      
    </div>
);

export default connect()(Billing);