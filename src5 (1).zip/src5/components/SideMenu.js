import React from 'react';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import AccountCircle from '@material-ui/icons/AccountCircle';
import ExitToApp from '@material-ui/icons/ExitToApp';
import { makeStyles } from '@material-ui/core/styles';
import { Avatar } from '@material-ui/core';
import { Grid } from '@material-ui/core';
import Button from '@material-ui/core/Button';
const drawerWidth = 240;

const useStyles = makeStyles(theme => ({
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
  },
  drawerPaper: {
    width: drawerWidth,
    backgroundImage: `linear-gradient(#cfd9df,#e2ebf0)`,
    color: 'grey',
  },
  bigAvatar: {
    margin: 30,
    width: 100,
    height: 100,
  },
}));

function SideMenu() {
  const classes = useStyles();

  return (
    <Drawer
      open={true}
      variant='permanent'
      anchor='left'
      className={classes.drawer}
      classes={{
        paper: classes.drawerPaper,
      }}
    >
      <Grid container justify='center' alignItems='center'>
        <Avatar
          src='https://lh3.googleusercontent.com/proxy/VJY3HNBPL62cTz-M7rMkCE0I1o7VyAjVUjhhgPr55ExShiQOJa8_ddIABSQCWpGYyLF9ienWBTXiPL-7G022SUUKxgAoCDZVz2gF7d-XWO8cg6qIMiF3tdhPGao'
          className={classes.bigAvatar}
        />
      </Grid>
      <List>
       <Button size="large" variant="contained" color="secondary" >
         About
       </Button><br/><br></br><br></br>
       <Button variant="contained" color="primary" size="large">
        Faq's
       </Button><br/><br></br><br></br>
       <Button variant="contained" color="Danger" size="large">
         Complaints
       </Button><br/><br></br><br></br>
      </List>
     

     
    </Drawer>
  );
}

export default SideMenu;
