package com.capg.cardpayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardpaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardpaymentApplication.class, args);
	}

}
