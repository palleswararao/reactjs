package com.capg.cardpayment.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.cardpayment.entities.CardPayment;
import com.capg.cardpayment.model.CardPaymentDTO;
import com.capg.cardpayment.service.ICardPaymentService;
@CrossOrigin
@RestController
@RequestMapping("api/pay")
public class CardPaymentController {
	@Autowired
	ICardPaymentService service;
	
	Logger logger = LoggerFactory.getLogger(CardPaymentController.class);
	
	
	@PostMapping(value = "/card",consumes = {"application/json"},produces = {"application/json"})
	public CardPaymentDTO addCardPayment(@RequestBody CardPayment pay1)
	{
		logger.info(" ------->>>  your UI payment page details are succesfully added to the card_info table in the payment database  <<<------ ");
		
		return service.addCardPayment(pay1);
	}

}
