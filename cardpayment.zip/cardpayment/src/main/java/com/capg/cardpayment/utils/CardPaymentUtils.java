package com.capg.cardpayment.utils;
import com.capg.cardpayment.entities.CardPayment;
import com.capg.cardpayment.model.CardPaymentDTO;



public class CardPaymentUtils {

	
	public static CardPayment convertToCardPayment(CardPaymentDTO cardPaymentdto) 
	{
		CardPayment cardPayment = new CardPayment();
		cardPayment.setPaymentId(cardPaymentdto.getPaymentId());
		cardPayment.setCardName(cardPaymentdto.getCardName());
		cardPayment.setCardNumber(cardPaymentdto.getCardNumber());
		cardPayment.setCvv(cardPaymentdto.getCvv());
		cardPayment.setExpiryDate(cardPaymentdto.getExpiryDate());
		cardPayment.setBillAmount(cardPaymentdto.getBillAmount());
		
		return cardPayment;
	}
	public static CardPaymentDTO convertToCardPaymentDTO(CardPayment cardPayment) 
	{
		CardPaymentDTO cardPaymentdto = new CardPaymentDTO();
		cardPaymentdto.setPaymentId(cardPayment.getPaymentId());
		cardPaymentdto.setCardName(cardPayment.getCardName());
		cardPaymentdto.setCardNumber(cardPayment.getCardNumber());
		cardPaymentdto.setCvv(cardPayment.getCvv());
		cardPaymentdto.setExpiryDate(cardPayment.getExpiryDate());
		cardPaymentdto.setBillAmount(cardPayment.getBillAmount());
		return cardPaymentdto;
	}
	

}
