package com.capg.cardpayment.exception;

public class CardPaymentNotFoundException extends RuntimeException {
	

		private static final long serialVersionUID = 1L;

		String message;

		public CardPaymentNotFoundException(String message) {
			this.message = message;
		}

		@Override
		public String getMessage() {
			return message;
		}

}
