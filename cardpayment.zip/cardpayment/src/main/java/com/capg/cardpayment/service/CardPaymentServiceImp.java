package com.capg.cardpayment.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capg.cardpayment.entities.CardPayment;
import com.capg.cardpayment.model.CardPaymentDTO;
import com.capg.cardpayment.repository.CardPaymentRepository;
import com.capg.cardpayment.utils.CardPaymentUtils;

@Service
public class CardPaymentServiceImp implements ICardPaymentService {

	@Autowired
	CardPaymentRepository repo;

	@Override
	public CardPaymentDTO addCardPayment(CardPayment pay) {
		CardPayment pay1 = repo.save(pay);
		CardPaymentDTO CardPaymentdto = CardPaymentUtils.convertToCardPaymentDTO(pay1);
		return CardPaymentdto;
	}

	
	
	 
				  
}
