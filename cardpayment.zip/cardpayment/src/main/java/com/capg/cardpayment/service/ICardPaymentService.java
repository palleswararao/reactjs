package com.capg.cardpayment.service;

import com.capg.cardpayment.entities.CardPayment;
import com.capg.cardpayment.model.CardPaymentDTO;


public interface ICardPaymentService{
	
	public CardPaymentDTO addCardPayment(CardPayment pay);
}