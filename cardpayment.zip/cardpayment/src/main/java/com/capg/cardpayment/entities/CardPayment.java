package com.capg.cardpayment.entities;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "card_info")
public class CardPayment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) 
	private int paymentId;
	@NotEmpty(message = "cardname cannot be empty")
	@Size(min = 4, max = 25)
	private String cardName;
	@NotNull(message = "cardno cannot be empty")
	@Pattern(regexp = "^[0-9]{16}$")
	private String cardNumber;
	@NotNull(message = "cvv cannot be null")
	@Pattern(regexp = "^[0-9]{3}$")
	private String cvv;
	@NotNull(message = "expirydate cannot be null") 
	@Pattern(regexp = "^(?:0[1-9]|1[0-2])/[0-9]{2}$")
	private String expiryDate;
	@NotNull(message = "billamount cannot be null") 
	private int billAmount;
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	@Override
	public String toString() {
		return "CardPayment [paymentId=" + paymentId + ", cardName=" + cardName + ", cardNumber=" + cardNumber
				+ ", cvv=" + cvv + ", expiryDate=" + expiryDate + ", billAmount=" + billAmount + "]";
	}
}
