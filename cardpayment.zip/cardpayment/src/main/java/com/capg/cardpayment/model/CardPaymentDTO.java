package com.capg.cardpayment.model;
import org.springframework.stereotype.Component;

@Component
public class CardPaymentDTO {
	private int paymentId;
	private String cardName;
	private String cardNumber;
	private String cvv;
	private String expiryDate;
	private int billAmount;
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	@Override
	public String toString() {
		return "CardPaymentDTO [paymentId=" + paymentId + ", cardName=" + cardName + ", cardNumber=" + cardNumber
				+ ", cvv=" + cvv + ", expiryDate=" + expiryDate + ", billAmount=" + billAmount + "]";
	}
}
	