//import { useEffect, useState } from "react";
import { Table } from "react-bootstrap";
import { useSelector } from "react-redux";
//import { useHistory } from "react-router";
// import {
//   // deletePaymentAction,
//   getAllPaymentAction,
//   getByIdPaymentAction,
//   updateRefPayment,
// } from "../redux/PaymentReducer";
//import { PaymentModal } from "./PaymentModal";

export function BillingList() {
  const state = useSelector((state) => state);
  // const dispatch = useDispatch();
  // const history = useHistory();
  console.log(state);

  //const [successOperation, setSuccessOperation] = useState(false);

  // Used to Initialize :: READ THE DATA FROM API
//   useEffect(() => {
//     dispatch(getAllPaymentAction());
//   }, []);

//   const updatePayment = (item) => {
//     // we are doing this so that we can access this object in the form page
//     dispatch(updateRefPayment(item));

//     // form page
//     history.push("/create-payment");
//   };

//  const getPaymentById = (item) => {
//     dispatch(getByIdPaymentAction(item));
//   };

  return (
    <>
      <div style={{ height: "200vh", backgroundColor: "#d9ecd0" }}>
        <div className="row">
          <div className="col-3 col-md-2 d-none d-md-block"></div>
          <div className="col-12 col-md-8">
            <h3 className="alert alert-primary text-center">Billing List</h3>

            {/* {successOperation && (
              <div className="alert alert-primary">Operation Success</div>
            )} */}

            <Table striped bordered hover variant="primary">

              
              <tr style={{ backgroundColor: "#89c5df" }}>
              <th scope="col">customerId</th>
                <th scope="col">billNum</th>
                <th scope="col">units</th>
                <th scope="col">grandTotal</th>
                <th scope="col">Date</th> 
              </tr>

              
              <tbody>
                {[...state.bill.list].map((item, index) => (
                  <tr key={index}>
                    <td>{item.customerId}</td>
                    <td>{item.billNum}</td>
                    <td>{item.units}</td>
                    <td>{item.grandTotal}</td>
                    <td>{item.Date}</td>
                  </tr>
                ))}
              </tbody>
              
            </Table>

          </div>
          <div className="col-3 col-md-2 d-none d-md-block"></div>
        </div>
      </div>

      {/** BILLING MODAL */}
      {/* <BillingModal /> */}
    </>
  );
}