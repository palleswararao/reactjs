// import logo from "./logo.svg";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import "./App.css";
import { BillingUpsert } from "./components/BillingUpsert";
import { BillingList } from "./components/BillingList";
// import { Nav, Navbar } from "react-bootstrap";
import { AppNavBar } from "./common/AppNavBar.js";

function App() {
  return (
    <Router>
      <AppNavBar />

      <Switch>
        
        <Route path="/bill done">
          <BillingUpsert />
        </Route>

        <Route path="/billinglist">
          <BillingList />
        </Route>

        <Route exact path="/">
          <BillingUpsert />
        </Route>

      </Switch>

    </Router>

  );
}

export default App;
